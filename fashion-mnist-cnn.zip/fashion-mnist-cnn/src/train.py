#!/usr/bin/env python3
"""
Train a CNN on Fashion-MNIST.

Usage:
    python -m src.train
    python -m src.train --epochs 20 --batch-size 128
"""

import argparse
import os
import sys
from pathlib import Path

import torch
import torch.nn as nn
import torch.optim as optim
from tqdm import tqdm
import yaml

# Make sure the package root is on the path
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.model import get_model
from src.utils import (
    set_seed,
    get_device,
    get_data_loaders,
    save_checkpoint,
    plot_training_curves,
)


def train_one_epoch(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    criterion: nn.Module,
    optimizer: torch.optim.Optimizer,
    device: torch.device,
    log_interval: int = 100,
) -> tuple[float, float]:
    """Train for one epoch. Returns (avg_loss, accuracy)."""
    model.train()
    running_loss = 0.0
    correct = 0
    total = 0

    pbar = tqdm(loader, desc="Train", leave=False)
    for batch_idx, (inputs, targets) in enumerate(pbar):
        inputs, targets = inputs.to(device), targets.to(device)

        optimizer.zero_grad()
        outputs = model(inputs)
        loss = criterion(outputs, targets)
        loss.backward()
        optimizer.step()

        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

        if (batch_idx + 1) % log_interval == 0:
            pbar.set_postfix(
                loss=f"{loss.item():.4f}",
                acc=f"{100.0 * correct / total:.2f}%",
            )

    avg_loss = running_loss / total
    accuracy = 100.0 * correct / total
    return avg_loss, accuracy


@torch.no_grad()
def evaluate(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    criterion: nn.Module,
    device: torch.device,
) -> tuple[float, float]:
    """Evaluate on a dataset. Returns (avg_loss, accuracy)."""
    model.eval()
    running_loss = 0.0
    correct = 0
    total = 0

    for inputs, targets in loader:
        inputs, targets = inputs.to(device), targets.to(device)
        outputs = model(inputs)
        loss = criterion(outputs, targets)

        running_loss += loss.item() * inputs.size(0)
        _, predicted = outputs.max(1)
        total += targets.size(0)
        correct += predicted.eq(targets).sum().item()

    avg_loss = running_loss / total
    accuracy = 100.0 * correct / total
    return avg_loss, accuracy


def main(args):
    # Load config
    config_path = ROOT / "configs" / "config.yaml"
    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)

    # Override with CLI args
    epochs = args.epochs or cfg["training"]["epochs"]
    batch_size = args.batch_size or cfg["data"]["batch_size"]
    lr = args.lr or cfg["training"]["learning_rate"]
    seed = args.seed or cfg["training"]["seed"]

    set_seed(seed)
    device = get_device(cfg["training"]["device"])
    print(f"Using device: {device}")

    # Data
    train_loader, test_loader = get_data_loaders(
        data_dir=cfg["data"]["data_dir"],
        batch_size=batch_size,
        num_workers=cfg["data"]["num_workers"],
    )
    print(f"Train samples: {len(train_loader.dataset):,}")
    print(f"Test  samples: {len(test_loader.dataset):,}")

    # Model
    model = get_model(
        name=cfg["model"]["name"],
        num_classes=cfg["model"]["num_classes"],
        dropout=cfg["model"]["dropout"],
    ).to(device)
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")

    # Loss, optimizer, scheduler
    criterion = nn.CrossEntropyLoss()
    optimizer = optim.Adam(
        model.parameters(),
        lr=lr,
        weight_decay=cfg["training"]["weight_decay"],
    )
    scheduler = optim.lr_scheduler.StepLR(
        optimizer,
        step_size=cfg["training"]["step_size"],
        gamma=cfg["training"]["gamma"],
    )

    # Training loop
    best_acc = 0.0
    train_losses, train_accs, test_accs = [], [], []

    print(f"\nStarting training for {epochs} epochs...\n")
    for epoch in range(1, epochs + 1):
        print(f"Epoch {epoch}/{epochs}")

        train_loss, train_acc = train_one_epoch(
            model, train_loader, criterion, optimizer, device,
            log_interval=cfg["logging"]["log_interval"],
        )
        test_loss, test_acc = evaluate(model, test_loader, criterion, device)

        scheduler.step()

        train_losses.append(train_loss)
        train_accs.append(train_acc)
        test_accs.append(test_acc)

        print(
            f"  Train Loss: {train_loss:.4f} | Train Acc: {train_acc:.2f}% | "
            f"Test Acc: {test_acc:.2f}% | LR: {scheduler.get_last_lr()[0]:.6f}"
        )

        # Save best model
        if test_acc > best_acc:
            best_acc = test_acc
            save_path = os.path.join(
                cfg["logging"]["save_dir"], "best_model.pth"
            )
            save_checkpoint(model, optimizer, epoch, test_acc, save_path)

    # Final plots
    plot_training_curves(
        train_losses,
        train_accs,
        test_accs,
        save_path=os.path.join(cfg["logging"]["results_dir"], "training_curves.png"),
    )

    print(f"\n[OK] Training finished. Best Test Accuracy: {best_acc:.2f}%")
    print(f"Best model saved at: {cfg['logging']['save_dir']}/best_model.pth")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Train CNN on Fashion-MNIST")
    parser.add_argument("--epochs", type=int, default=None, help="Number of epochs")
    parser.add_argument("--batch-size", type=int, default=None, help="Batch size")
    parser.add_argument("--lr", type=float, default=None, help="Learning rate")
    parser.add_argument("--seed", type=int, default=None, help="Random seed")
    args = parser.parse_args()
    main(args)
