"""
CNN model definition for Fashion-MNIST classification.
"""

import torch
import torch.nn as nn
import torch.nn.functional as F


class SimpleCNN(nn.Module):
    """
    A lightweight Convolutional Neural Network for Fashion-MNIST.

    Architecture:
        - Conv1: 1 -> 32 channels, 3x3 kernel
        - Conv2: 32 -> 64 channels, 3x3 kernel
        - MaxPool + Dropout
        - Fully connected layers with dropout
    """

    def __init__(self, num_classes: int = 10, dropout: float = 0.25):
        super(SimpleCNN, self).__init__()

        self.features = nn.Sequential(
            # Block 1
            nn.Conv2d(1, 32, kernel_size=3, padding=1),
            nn.BatchNorm2d(32),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),  # 28x28 -> 14x14

            # Block 2
            nn.Conv2d(32, 64, kernel_size=3, padding=1),
            nn.BatchNorm2d(64),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),  # 14x14 -> 7x7

            # Block 3
            nn.Conv2d(64, 128, kernel_size=3, padding=1),
            nn.BatchNorm2d(128),
            nn.ReLU(inplace=True),
            nn.MaxPool2d(2, 2),  # 7x7 -> 3x3
        )

        self.classifier = nn.Sequential(
            nn.Dropout(dropout),
            nn.Linear(128 * 3 * 3, 256),
            nn.ReLU(inplace=True),
            nn.Dropout(dropout),
            nn.Linear(256, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        x = self.features(x)
        x = torch.flatten(x, 1)
        x = self.classifier(x)
        return x


def get_model(name: str = "SimpleCNN", num_classes: int = 10, dropout: float = 0.25) -> nn.Module:
    """Factory function to create models."""
    if name == "SimpleCNN":
        return SimpleCNN(num_classes=num_classes, dropout=dropout)
    else:
        raise ValueError(f"Unknown model: {name}")


if __name__ == "__main__":
    # Quick sanity check
    model = SimpleCNN()
    dummy = torch.randn(4, 1, 28, 28)
    out = model(dummy)
    print(f"Input shape: {dummy.shape}")
    print(f"Output shape: {out.shape}")
    print(f"Total parameters: {sum(p.numel() for p in model.parameters()):,}")
