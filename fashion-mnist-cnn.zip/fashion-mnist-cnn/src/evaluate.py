#!/usr/bin/env python3
"""
Evaluate a trained Fashion-MNIST CNN and generate reports/plots.

Usage:
    python -m src.evaluate
    python -m src.evaluate --checkpoint ./models/best_model.pth
"""

import argparse
import os
import sys
from pathlib import Path

import numpy as np
import torch
import torch.nn as nn
import yaml
from tqdm import tqdm

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from src.model import get_model
from src.utils import (
    set_seed,
    get_device,
    get_data_loaders,
    load_checkpoint,
    plot_confusion_matrix,
    print_classification_report,
    CLASS_NAMES,
)


@torch.no_grad()
def get_predictions(
    model: nn.Module,
    loader: torch.utils.data.DataLoader,
    device: torch.device,
) -> tuple[np.ndarray, np.ndarray]:
    """Collect all predictions and true labels."""
    model.eval()
    all_preds = []
    all_targets = []

    for inputs, targets in tqdm(loader, desc="Evaluating"):
        inputs = inputs.to(device)
        outputs = model(inputs)
        preds = outputs.argmax(dim=1).cpu().numpy()
        all_preds.append(preds)
        all_targets.append(targets.numpy())

    return np.concatenate(all_targets), np.concatenate(all_preds)


def main(args):
    config_path = ROOT / "configs" / "config.yaml"
    with open(config_path, "r") as f:
        cfg = yaml.safe_load(f)

    set_seed(cfg["training"]["seed"])
    device = get_device(cfg["training"]["device"])
    print(f"Using device: {device}")

    # Data
    _, test_loader = get_data_loaders(
        data_dir=cfg["data"]["data_dir"],
        batch_size=cfg["data"]["batch_size"],
        num_workers=cfg["data"]["num_workers"],
    )

    # Model
    model = get_model(
        name=cfg["model"]["name"],
        num_classes=cfg["model"]["num_classes"],
        dropout=cfg["model"]["dropout"],
    ).to(device)

    # Load weights
    checkpoint_path = args.checkpoint or os.path.join(
        cfg["logging"]["save_dir"], "best_model.pth"
    )
    if not os.path.exists(checkpoint_path):
        raise FileNotFoundError(
            f"Checkpoint not found: {checkpoint_path}\n"
            "Please train the model first with: python -m src.train"
        )

    load_checkpoint(model, checkpoint_path, device)

    # Predictions
    y_true, y_pred = get_predictions(model, test_loader, device)

    # Accuracy
    accuracy = 100.0 * np.mean(y_true == y_pred)
    print(f"\nTest Accuracy: {accuracy:.2f}%")

    # Detailed report
    print_classification_report(y_true, y_pred)

    # Confusion matrix
    cm_path = os.path.join(cfg["logging"]["results_dir"], "confusion_matrix.png")
    plot_confusion_matrix(y_true, y_pred, save_path=cm_path)

    print(f"\n[OK] Evaluation complete. Results saved in {cfg['logging']['results_dir']}/")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Evaluate Fashion-MNIST CNN")
    parser.add_argument(
        "--checkpoint",
        type=str,
        default=None,
        help="Path to model checkpoint (.pth)",
    )
    args = parser.parse_args()
    main(args)
